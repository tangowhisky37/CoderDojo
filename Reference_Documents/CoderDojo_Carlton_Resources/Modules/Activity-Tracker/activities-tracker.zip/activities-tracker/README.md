Project
1. Home Page - static with menu
2. About me - static with nav
3. Favourite video games - form
   Name of the game
   Description
   Image
4. Video games view - static table display

5. Game diary - form with date and
6. diary display


